第四章：累积耗散相位与正曲率薄壳几何（讨论内容增补版）
基于上传的符号随文解释版源码直接增补。正文保留原定义、引理、命题、定理编号，新增四幅 TikZ 图（直接包含于 main.tex）。
在本目录使用 XeLaTeX 编译 main.tex 两次。需要 ctex、TikZ、tcolorbox 等 TeX Live 宏包及 Liberation Serif/Sans、Noto Serif/Sans CJK SC 系统字体。
